import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

// Điều hướng
type RootStackParamList = {
  Home: { selectedColor?: string } | undefined;
  ColorPicker: { currentColor?: string };
};

const Stack = createNativeStackNavigator<RootStackParamList>();

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="ColorPicker"
          component={ColorPickerScreen}
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;

// ---------------------- Home Screen ----------------------

const HomeScreen = ({ navigation, route }: any) => {
  const selectedColor = route?.params?.selectedColor || null;

  // Map màu -> ảnh
  const colorImageMap: Record<string, string> = {
    Tím: 'https://cdn.tgdd.vn/Products/Images/42/217920/vsmart-joy-3-tim-600x600-600x600.jpg',
    Đỏ: 'https://product.hstatic.net/1000238589/product/vsmart-star-coral-400x460_a53afcdd94234dabbc5a6dd7b7843472.png',
    Đen: 'https://cdn.tgdd.vn/Products/Images/42/217920/vsmart-joy-3-den-200x200-750x500.png',
    'Xanh dương':
      'https://cdn.tgdd.vn/Products/Images/42/217436/vsmart-active-3-600x600-600x600.jpg',
  };

  const imageUri = selectedColor
    ? colorImageMap[selectedColor]
    : colorImageMap['Tím'];

  return (
    <View style={styles.container}>
      {/* Ảnh sản phẩm */}
      <View style={styles.productImageContainer}>
        <Image source={{ uri: imageUri }} style={styles.productImage} />
      </View>

      {/* Thông tin sản phẩm */}
      <Text style={styles.productName}>
        Điện Thoại Vsmart Joy 3 - Hàng chính hãng
      </Text>

      <View style={styles.ratingRow}>
        <Text style={styles.starText}>★★★★★</Text>
        <Text style={styles.reviewText}>(Xem 828 đánh giá)</Text>
      </View>

      <View style={styles.priceRow}>
        <Text style={styles.price}>1.790.000 đ</Text>
        <Text style={styles.oldPrice}>1.790.000 đ</Text>
      </View>

      <Text style={styles.cashbackText}>Ở ĐÂU RẺ HƠN HOÀN TIỀN</Text>

      {/* Nút chọn màu */}
      <TouchableOpacity
        style={styles.chooseColorBtn}
        onPress={() =>
          navigation.navigate('ColorPicker', { currentColor: selectedColor })
        }>
        <Text>4 MÀU - CHỌN MÀU</Text>
      </TouchableOpacity>

      {/* Nút mua */}
      <TouchableOpacity style={styles.buyButton}>
        <Text style={styles.buyButtonText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </View>
  );
};

// ---------------------- Color Picker Screen ----------------------

const ColorPickerScreen = ({ navigation, route }: any) => {
  const currentColor = route?.params?.currentColor || null;
  const [selectedColor, setSelectedColor] = useState(currentColor);

  const colors = ['Tím', 'Đỏ', 'Đen', 'Xanh dương'];
  const colorCodeMap: Record<string, string> = {
    Tím: '#BB86FC',
    Đỏ: '#FF3D00',
    Đen: '#000000',
    'Xanh dương': '#2962FF',
  };

  const imageMap: Record<string, string> = {
    Tím: 'https://cdn.tgdd.vn/Products/Images/42/217920/vsmart-joy-3-tim-600x600-600x600.jpg',
    Đỏ: 'https://product.hstatic.net/1000238589/product/vsmart-star-coral-400x460_a53afcdd94234dabbc5a6dd7b7843472.png',
    Đen: 'https://cdn.tgdd.vn/Products/Images/42/217920/vsmart-joy-3-den-200x200-750x500.png',
    'Xanh dương':
      'https://cdn.tgdd.vn/Products/Images/42/217436/vsmart-active-3-600x600-600x600.jpg',
  };

  return (
    <View style={styles.colorScreenContainer}>
      {/* Header */}
      <View style={styles.headerRow}>
        <Image
          source={{ uri: imageMap[selectedColor || 'Tím'] }}
          style={{ width: 70, height: 70, marginRight: 10 }}
        />
        <View style={{ flex: 1 }}>
          <Text style={{ fontWeight: 'bold' }}>
            Điện Thoại Vsmart Joy 3{'\n'}Hàng chính hãng
          </Text>
          {selectedColor && (
            <Text style={{ marginTop: 4 }}>
              Màu: <Text style={{ fontWeight: 'bold' }}>{selectedColor}</Text>
            </Text>
          )}
          <Text style={{ marginTop: 4 }}>
            Cung cấp bởi{' '}
            <Text style={{ fontWeight: 'bold' }}>Tiki Tradding</Text>
          </Text>
          <Text style={styles.price}>1.790.000 đ</Text>
        </View>
      </View>

      {/* Danh sách màu */}
      <Text style={{ marginVertical: 10 }}>Chọn một màu bên dưới:</Text>
      <ScrollView contentContainerStyle={{ alignItems: 'center' }}>
        {colors.map((color) => (
          <TouchableOpacity
            key={color}
            style={[
              styles.colorBox,
              {
                backgroundColor: colorCodeMap[color],
                borderWidth: selectedColor === color ? 3 : 1,
                borderColor: selectedColor === color ? '#2196F3' : '#ccc',
                alignSelf: 'center', // căn giữa từng ô
              },
            ]}
            onPress={() => setSelectedColor(color)}
          />
        ))}
      </ScrollView>

      {/* Nút XONG */}
      <TouchableOpacity
        style={styles.doneButton}
        onPress={() => navigation.navigate('Home', { selectedColor })}>
        <Text style={{ color: 'white', fontWeight: 'bold' }}>XONG</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  productImageContainer: {
    alignItems: 'center',
    marginVertical: 20,
  },
  productImage: {
    width: 250,
    height: 250,
    resizeMode: 'contain',
  },
  productName: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: '500',
  },
  ratingRow: {
    flexDirection: 'row',
    marginTop: 5,
  },
  starText: {
    color: '#FFD700',
  },
  reviewText: {
    marginLeft: 8,
    color: 'gray',
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  price: {
    fontSize: 18,
    color: 'red',
    fontWeight: 'bold',
  },
  oldPrice: {
    fontSize: 16,
    color: '#999',
    marginLeft: 10,
    textDecorationLine: 'line-through',
  },
  cashbackText: {
    color: 'red',
    marginTop: 6,
    fontWeight: '500',
  },
  chooseColorBtn: {
    marginTop: 20,
    padding: 14,
    backgroundColor: '#ddd',
    alignItems: 'center',
    borderRadius: 6,
  },
  buyButton: {
    marginTop: 20,
    backgroundColor: '#e53935',
    paddingVertical: 14,
    alignItems: 'center',
    borderRadius: 6,
  },
  buyButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },

  colorScreenContainer: {
    flex: 1,
    padding: 20,
    backgroundColor: '#ccc',
  },
  headerRow: {
    flexDirection: 'row',
    marginBottom: 10,
    backgroundColor: 'white',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  colorBox: {
    width: 70,
    height: 70,
    borderRadius: 6,
    marginVertical: 8,
  },

  doneButton: {
    marginTop: 20,
    backgroundColor: '#3F51B5',
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 6,
  },
});
