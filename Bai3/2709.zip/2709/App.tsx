import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  TextInput,
  FlatList,
} from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

// -------------------- Type & API --------------------

type RootStackParamList = {
  Home: { selectedColor?: string } | undefined;
  ColorPicker: { currentColor?: string };
};

type ProductData = {
  id?: string;
  productName: string;
  colors: string[];
  colorCodeMap: Record<string, string>;
  colorImageMap: Record<string, string>;
  price: string;
  oldPrice: string;
  rating: string;
  reviewCount: number;
  cashbackText: string;
  supplier: string;
};

const API_URL = 'https://67f56b1e913986b16fa4846b.mockapi.io/Lab5';

const fetchProductData = async (): Promise<ProductData> => {
  const res = await fetch(API_URL);
  const json = await res.json();
  return Array.isArray(json) ? json[0] : json;
};

// -------------------- Navigation Setup --------------------

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator();

const HomeStack = () => (
  <Stack.Navigator>
    <Stack.Screen name="Home" component={HomeScreen} options={{ headerShown: false }} />
    <Stack.Screen name="ColorPicker" component={ColorPickerScreen} options={{ headerShown: false }} />
  </Stack.Navigator>
);

// -------------------- Home Screen --------------------

const HomeScreen = ({ navigation, route }: any) => {
  const selectedColor = route?.params?.selectedColor || null;
  const [data, setData] = useState<ProductData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProductData()
      .then(setData)
      .finally(() => setLoading(false));
  }, []);

  if (loading || !data) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#2196F3" />
      </View>
    );
  }

  const imageUri = selectedColor
    ? data.colorImageMap[selectedColor]
    : data.colorImageMap['Tím'];

  return (
    <View style={styles.container}>
      <View style={styles.productImageContainer}>
        <Image source={{ uri: imageUri }} style={styles.productImage} />
      </View>

      <Text style={styles.productName}>{data.productName}</Text>

      <View style={styles.ratingRow}>
        <Text style={styles.starText}>{data.rating}</Text>
        <Text style={styles.reviewText}>(Xem {data.reviewCount} đánh giá)</Text>
      </View>

      <View style={styles.priceRow}>
        <Text style={styles.price}>{data.price}</Text>
        <Text style={styles.oldPrice}>{data.oldPrice}</Text>
      </View>

      <Text style={styles.cashbackText}>{data.cashbackText}</Text>

      <TouchableOpacity
        style={styles.chooseColorBtn}
        onPress={() =>
          navigation.navigate('ColorPicker', { currentColor: selectedColor })
        }>
        <Text>4 MÀU - CHỌN MÀU</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.buyButton}>
        <Text style={styles.buyButtonText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </View>
  );
};

// -------------------- Color Picker Screen --------------------

const ColorPickerScreen = ({ navigation, route }: any) => {
  const currentColor = route?.params?.currentColor || null;
  const [selectedColor, setSelectedColor] = useState(currentColor);
  const [data, setData] = useState<ProductData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProductData()
      .then(setData)
      .finally(() => setLoading(false));
  }, []);

  if (loading || !data) {
    return (
      <View style={styles.centered}>
        <ActivityIndicator size="large" color="#2196F3" />
      </View>
    );
  }

  return (
    <View style={styles.colorScreenContainer}>
      <View style={styles.headerRow}>
        <Image
          source={{ uri: data.colorImageMap[selectedColor || 'Tím'] }}
          style={{ width: 70, height: 70, marginRight: 10 }}
        />
        <View style={{ flex: 1 }}>
          <Text style={{ fontWeight: 'bold' }}>{data.productName}</Text>
          <Text style={{ marginTop: 4 }}>
            Màu: <Text style={{ fontWeight: 'bold' }}>{selectedColor}</Text>
          </Text>
          <Text style={{ marginTop: 4 }}>
            Cung cấp bởi{' '}
            <Text style={{ fontWeight: 'bold' }}>{data.supplier}</Text>
          </Text>
          <Text style={styles.price}>{data.price}</Text>
        </View>
      </View>

      <Text style={{ marginVertical: 10 }}>Chọn một màu bên dưới:</Text>
      <ScrollView contentContainerStyle={{ alignItems: 'center' }}>
        {data.colors.map((color) => (
          <TouchableOpacity
            key={color}
            style={[
              styles.colorBox,
              {
                backgroundColor: data.colorCodeMap[color],
                borderWidth: selectedColor === color ? 3 : 1,
                borderColor: selectedColor === color ? '#2196F3' : '#ccc',
              },
            ]}
            onPress={() => setSelectedColor(color)}
          />
        ))}
      </ScrollView>

      <TouchableOpacity
        style={styles.doneButton}
        onPress={() => navigation.navigate('Home', { selectedColor })}>
        <Text style={{ color: 'white', fontWeight: 'bold' }}>XONG</Text>
      </TouchableOpacity>
    </View>
  );
};

// -------------------- Search Screen --------------------

const SearchScreen = () => {
  const [keyword, setKeyword] = useState('');
  return (
    <View style={styles.container}>
      <TextInput
        placeholder="Nhập từ khóa tìm kiếm..."
        value={keyword}
        onChangeText={setKeyword}
        style={{
          borderWidth: 1,
          borderColor: '#ccc',
          padding: 10,
          borderRadius: 8,
        }}
      />
      <Text style={{ marginTop: 20 }}>Từ khóa: {keyword}</Text>
    </View>
  );
};

// -------------------- Profile Screen --------------------

const ProfileScreen = () => {
  return (
    <View style={styles.centered}>
      <Image
        source={{ uri: 'https://cdn2.fptshop.com.vn/small/avatar_trang_1_cd729c335b.jpg' }}
        style={{ width: 100, height: 100, borderRadius: 50 }}
      />
      <Text style={{ marginTop: 16, fontSize: 18, fontWeight: 'bold' }}>
        Nguyễn Ngọc Hiền
      </Text>
    </View>
  );
};

// -------------------- App Entry --------------------

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ color, size }) => {
            let iconName = 'home';
            if (route.name === 'HomeTab') iconName = 'home';
            else if (route.name === 'Search') iconName = 'search';
            else if (route.name === 'Profile') iconName = 'person';

            return <Ionicons name={iconName} size={size} color={color} />;
          },
          headerShown: false,
        })}>
        <Tab.Screen name="HomeTab" component={HomeStack} options={{ title: 'Home' }} />
        <Tab.Screen name="Search" component={SearchScreen} />
        <Tab.Screen name="Profile" component={ProfileScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  productImageContainer: {
    alignItems: 'center',
    marginVertical: 20,
  },
  productImage: {
    width: 250,
    height: 250,
    resizeMode: 'contain',
  },
  productName: {
    fontSize: 16,
    fontWeight: '500',
  },
  ratingRow: {
    flexDirection: 'row',
    marginTop: 5,
  },
  starText: {
    color: '#FFD700',
  },
  reviewText: {
    marginLeft: 8,
    color: 'gray',
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  price: {
    fontSize: 18,
    color: 'red',
    fontWeight: 'bold',
  },
  oldPrice: {
    fontSize: 16,
    color: '#999',
    marginLeft: 10,
    textDecorationLine: 'line-through',
  },
  cashbackText: {
    color: 'red',
    marginTop: 6,
    fontWeight: '500',
  },
  chooseColorBtn: {
    marginTop: 20,
    padding: 14,
    backgroundColor: '#ddd',
    alignItems: 'center',
    borderRadius: 6,
  },
  buyButton: {
    marginTop: 20,
    backgroundColor: '#e53935',
    paddingVertical: 14,
    alignItems: 'center',
    borderRadius: 6,
  },
  buyButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },
  colorScreenContainer: {
    flex: 1,
    padding: 20,
    backgroundColor: '#eee',
  },
  headerRow: {
    flexDirection: 'row',
    marginBottom: 10,
    backgroundColor: 'white',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  colorBox: {
    width: 70,
    height: 70,
    borderRadius: 6,
    marginVertical: 8,
  },
  doneButton: {
    marginTop: 20,
    backgroundColor: '#3F51B5',
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 6,
  },
});
