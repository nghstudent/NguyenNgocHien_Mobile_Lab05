import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  ActivityIndicator,
} from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

type RootStackParamList = {
  Home: { selectedColor?: string } | undefined;
  ColorPicker: { currentColor?: string };
};

const Stack = createNativeStackNavigator<RootStackParamList>();

// Kiểu dữ liệu sản phẩm tương ứng với API
type ProductData = {
  id?: string;
  productName: string;
  colors: string[];
  colorCodeMap: Record<string, string>;
  colorImageMap: Record<string, string>;
  price: string;
  oldPrice: string;
  rating: string;
  reviewCount: number;
  cashbackText: string;
  supplier: string;
};

const API_URL = 'https://67f56b1e913986b16fa4846b.mockapi.io/Lab5';

const fetchProductData = async (): Promise<ProductData> => {
  const resp = await fetch(API_URL);
  const json = await resp.json();

  // Nếu API trả về mảng, lấy phần tử đầu
  if (Array.isArray(json)) {
    if (json.length > 0) {
      return json[0];
    } else {
      throw new Error('API trả về mảng rỗng');
    }
  }
  // nếu là object
  return json;
};

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen
          name="ColorPicker"
          component={ColorPickerScreen}
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;

// ---------------------- Home Screen ----------------------

const HomeScreen = ({ navigation, route }: any) => {
  const selectedColor = route?.params?.selectedColor || null;
  const [data, setData] = useState<ProductData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchProductData()
      .then((res) => {
        setData(res);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error fetching product:', err);
        setError(err.message || 'Error');
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#2196F3" />
      </View>
    );
  }
  if (error) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ color: 'red' }}>Lỗi: {error}</Text>
      </View>
    );
  }
  if (!data) {
    return (
      <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text>Không có dữ liệu</Text>
      </View>
    );
  }

  const imageUri = selectedColor
    ? data.colorImageMap[selectedColor]
    : data.colorImageMap['Tím'];

  return (
    <View style={styles.container}>
      <View style={styles.productImageContainer}>
        <Image source={{ uri: imageUri }} style={styles.productImage} />
      </View>

      <Text style={styles.productName}>{data.productName}</Text>

      <View style={styles.ratingRow}>
        <Text style={styles.starText}>{data.rating}</Text>
        <Text style={styles.reviewText}>(Xem {data.reviewCount} đánh giá)</Text>
      </View>

      <View style={styles.priceRow}>
        <Text style={styles.price}>{data.price}</Text>
        <Text style={styles.oldPrice}>{data.oldPrice}</Text>
      </View>

      <Text style={styles.cashbackText}>{data.cashbackText}</Text>

      <TouchableOpacity
        style={styles.chooseColorBtn}
        onPress={() =>
          navigation.navigate('ColorPicker', { currentColor: selectedColor })
        }>
        <Text>4 MÀU - CHỌN MÀU</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.buyButton}>
        <Text style={styles.buyButtonText}>CHỌN MUA</Text>
      </TouchableOpacity>
    </View>
  );
};

// ---------------------- Color Picker Screen ----------------------

const ColorPickerScreen = ({ navigation, route }: any) => {
  const currentColor = route?.params?.currentColor || null;
  const [selectedColor, setSelectedColor] = useState<string | null>(currentColor);
  const [data, setData] = useState<ProductData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchProductData()
      .then((res) => {
        setData(res);
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error fetching product:', err);
        setError(err.message || 'Error');
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <View style={[styles.colorScreenContainer, { justifyContent: 'center', alignItems: 'center' }]}>
        <ActivityIndicator size="large" color="#2196F3" />
      </View>
    );
  }
  if (error) {
    return (
      <View style={[styles.colorScreenContainer, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ color: 'red' }}>Lỗi: {error}</Text>
      </View>
    );
  }
  if (!data) {
    return (
      <View style={[styles.colorScreenContainer, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text>Không có dữ liệu</Text>
      </View>
    );
  }

  return (
    <View style={styles.colorScreenContainer}>
      <View style={styles.headerRow}>
        <Image
          source={{ uri: data.colorImageMap[selectedColor || 'Tím'] }}
          style={{ width: 70, height: 70, marginRight: 10 }}
        />
        <View style={{ flex: 1 }}>
          <Text style={{ fontWeight: 'bold' }}>{data.productName}</Text>
          {selectedColor && (
            <Text style={{ marginTop: 4 }}>
              Màu: <Text style={{ fontWeight: 'bold' }}>{selectedColor}</Text>
            </Text>
          )}
          <Text style={{ marginTop: 4 }}>
            Cung cấp bởi{' '}
            <Text style={{ fontWeight: 'bold' }}>{data.supplier}</Text>
          </Text>
          <Text style={styles.price}>{data.price}</Text>
        </View>
      </View>

      <Text style={{ marginVertical: 10 }}>Chọn một màu bên dưới:</Text>
      <ScrollView contentContainerStyle={{ alignItems: 'center' }}>
        {data.colors.map((color) => (
          <TouchableOpacity
            key={color}
            style={[
              styles.colorBox,
              {
                backgroundColor: data.colorCodeMap[color],
                borderWidth: selectedColor === color ? 3 : 1,
                borderColor: selectedColor === color ? '#2196F3' : '#ccc',
                alignSelf: 'center',
              },
            ]}
            onPress={() => setSelectedColor(color)}
          />
        ))}
      </ScrollView>

      <TouchableOpacity
        style={styles.doneButton}
        onPress={() => navigation.navigate('Home', { selectedColor })}>
        <Text style={{ color: 'white', fontWeight: 'bold' }}>XONG</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  productImageContainer: {
    alignItems: 'center',
    marginVertical: 20,
  },
  productImage: {
    width: 250,
    height: 250,
    resizeMode: 'contain',
  },
  productName: {
    marginTop: 10,
    fontSize: 16,
    fontWeight: '500',
  },
  ratingRow: {
    flexDirection: 'row',
    marginTop: 5,
  },
  starText: {
    color: '#FFD700',
  },
  reviewText: {
    marginLeft: 8,
    color: 'gray',
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },
  price: {
    fontSize: 18,
    color: 'red',
    fontWeight: 'bold',
  },
  oldPrice: {
    fontSize: 16,
    color: '#999',
    marginLeft: 10,
    textDecorationLine: 'line-through',
  },
  cashbackText: {
    color: 'red',
    marginTop: 6,
    fontWeight: '500',
  },
  chooseColorBtn: {
    marginTop: 20,
    padding: 14,
    backgroundColor: '#ddd',
    alignItems: 'center',
    borderRadius: 6,
  },
  buyButton: {
    marginTop: 20,
    backgroundColor: '#e53935',
    paddingVertical: 14,
    alignItems: 'center',
    borderRadius: 6,
  },
  buyButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 16,
  },

  colorScreenContainer: {
    flex: 1,
    padding: 20,
    backgroundColor: '#ccc',
  },
  headerRow: {
    flexDirection: 'row',
    marginBottom: 10,
    backgroundColor: 'white',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  colorBox: {
    width: 70,
    height: 70,
    borderRadius: 6,
    marginVertical: 8,
  },

  doneButton: {
    marginTop: 20,
    backgroundColor: '#3F51B5',
    paddingVertical: 12,
    alignItems: 'center',
    borderRadius: 6,
  },
});
